import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Clock, Lock, Mail, ShieldCheck, Sun } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { session, rolePath } from "@/lib/hooks";
import type { Role } from "@/lib/types";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { HeroGradientOverlay, HeroStaticVideo } from "./components/-HeroBackdrop";

export const Route = createFileRoute("/(landing)/login")({
  head: () => ({ meta: [{ title: "Login — PMIS" }] }),
  component: LoginPage,
});

const QUICK: { role: Role; label: string; email: string }[] = [
  { role: "ipp", label: "IPP", email: "ipp@demo.com" },
  { role: "officer", label: "Officer", email: "officer@demo.com" },
  { role: "approver", label: "Approver", email: "approver@demo.com" },
  { role: "admin", label: "Admin", email: "admin@demo.com" },
  { role: "management", label: "Management", email: "management@demo.com" },
];

function LoginPage() {
  const [email, setEmail] = useState("ipp@demo.com");
  const [password, setPassword] = useState("demo");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const u = session.login(email, password);
      toast.success(`Welcome back, ${u.name}`);
      navigate({ to: rolePath(u.role) as never });
    } catch (err) {
      toast.error((err as Error).message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <div className="relative hidden flex-col justify-between overflow-hidden bg-slate-950 p-12 text-white lg:flex">
        <HeroStaticVideo />
        <HeroGradientOverlay />
        <div
          className="pointer-events-none absolute inset-x-0 bottom-0 h-36 bg-gradient-to-t from-slate-950/70 to-transparent"
          aria-hidden
        />
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_90%_80%_at_0%_100%,oklch(0.55_0.12_200/0.2),transparent_55%),radial-gradient(ellipse_70%_60%_at_100%_0%,oklch(0.72_0.14_72/0.12),transparent_50%)]" aria-hidden />
        <div className="relative z-10 flex flex-1 flex-col justify-between">
          <Link to="/" className="flex items-center gap-3 transition-opacity hover:opacity-90">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl border border-renewable-solar/50 bg-gradient-to-br from-renewable-solar/35 to-renewable-wind/25 shadow-lg shadow-primary/30 ring-1 ring-white/25">
              <Sun className="h-5 w-5 text-white" />
            </div>
            <div>
              <div className="text-lg font-semibold tracking-tight">PMIS</div>
              <div className="text-xs font-medium uppercase tracking-wider text-white/70">Renewable governance</div>
            </div>
          </Link>
          <div className="max-w-lg">
            <h1 className="text-balance text-4xl font-semibold tracking-tight drop-shadow-md md:text-[2.35rem] md:leading-[1.15]">
              Sign in to your renewable governance workspace
            </h1>
            <p className="mt-5 text-base leading-relaxed text-white/90 drop-shadow-sm md:text-[1.05rem]">
              All actions are audited. SLA timers run on every stage. One portal for IPPs, officers, approvers, admins,
              and management.
            </p>
            <ul className="mt-8 grid gap-3 sm:grid-cols-2">
              {[
                { icon: ShieldCheck, text: "Role-based access & audit trail" },
                { icon: Clock, text: "SLA-aware queues and escalations" },
              ].map(({ icon: Icon, text }) => (
                <li
                  key={text}
                  className="flex items-start gap-3 rounded-xl border border-white/10 bg-white/[0.06] px-4 py-3 text-sm leading-snug text-white/92 backdrop-blur-md"
                >
                  <Icon className="mt-0.5 size-4 shrink-0 text-renewable-solar" aria-hidden />
                  {text}
                </li>
              ))}
            </ul>
          </div>
          <div className="max-w-md rounded-xl border border-white/10 bg-white/[0.04] px-4 py-3 text-xs leading-relaxed text-white/88 backdrop-blur-sm">
            Demo accounts — use any role with password{" "}
            <span className="rounded bg-white/10 px-1.5 py-0.5 font-mono text-renewable-solar">demo</span>
          </div>
        </div>
      </div>

      <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-background px-4 py-10 sm:px-6">
        <div
          className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_85%_70%_at_50%_-10%,oklch(0.55_0.1_200/0.12),transparent_55%),radial-gradient(ellipse_60%_50%_at_100%_80%,oklch(0.78_0.14_72/0.1),transparent_50%)] dark:opacity-80"
          aria-hidden
        />
        <div className="relative z-10 w-full max-w-md">
          <div className="mb-8 flex items-center gap-3 lg:hidden">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-primary/85 text-primary-foreground shadow-lg shadow-primary/25 ring-1 ring-primary/20">
              <Sun className="h-5 w-5" />
            </div>
            <div>
              <div className="font-semibold tracking-tight">PMIS</div>
              <div className="text-xs text-muted-foreground">Staff & IPP sign-in</div>
            </div>
          </div>

          <div className="rounded-2xl border border-primary/12 bg-card/80 p-8 shadow-[0_32px_90px_-48px_oklch(0.25_0.08_262/0.45)] ring-1 ring-primary/[0.06] backdrop-blur-2xl dark:bg-card/55 dark:ring-primary/10 sm:p-9">
            <div className="mb-8">
              <h2 className="text-2xl font-semibold tracking-tight">Welcome back</h2>
              <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">
                Sign in with your work email, or pick a demo role below.
              </p>
            </div>

            <form onSubmit={submit} className="space-y-5">
              <div className="space-y-2">
                <Label htmlFor="login-email">Email</Label>
                <div className="relative">
                  <Mail
                    className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground"
                    aria-hidden
                  />
                  <Input
                    id="login-email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    type="email"
                    required
                    autoComplete="email"
                    placeholder="you@department.gov.in"
                    className="h-10 pl-9"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <Label htmlFor="login-password">Password</Label>
                  <span className="text-xs text-muted-foreground">Demo: use demo</span>
                </div>
                <div className="relative">
                  <Lock
                    className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground"
                    aria-hidden
                  />
                  <Input
                    id="login-password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    type="password"
                    required
                    autoComplete="current-password"
                    className="h-10 pl-9"
                  />
                </div>
              </div>
              <Button type="submit" disabled={loading} size="lg" className="mt-2 h-11 w-full text-[0.95rem] shadow-lg shadow-primary/20">
                {loading ? "Signing in…" : "Sign in"}
              </Button>
            </form>

            <div className="relative my-8">
              <div className="absolute inset-0 flex items-center" aria-hidden>
                <div className="w-full border-t border-border" />
              </div>
              <div className="relative flex justify-center text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                <span className="bg-card/90 px-3 dark:bg-card/80">Quick demo</span>
              </div>
            </div>

            <div className="flex flex-wrap gap-2">
              {QUICK.map((q) => (
                <button
                  key={q.role}
                  type="button"
                  onClick={() => {
                    setEmail(q.email);
                    setPassword("demo");
                  }}
                  className={cn(
                    "rounded-lg border border-border bg-background/80 px-3 py-2 text-left text-xs transition",
                    "hover:border-primary/30 hover:bg-primary/[0.04] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
                  )}
                >
                  <div className="font-semibold text-foreground">{q.label}</div>
                  <div className="mt-0.5 max-w-[140px] truncate text-muted-foreground">{q.email}</div>
                </button>
              ))}
            </div>

            <p className="mt-8 text-center text-sm text-muted-foreground">
              New IPP?{" "}
              <Link to="/register" className="font-semibold text-primary underline-offset-4 hover:underline">
                Register
              </Link>
              <span className="mx-2 text-border">·</span>
              <Link to="/roles" className="font-semibold text-primary underline-offset-4 hover:underline">
                Demo roles
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
