import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { db, session } from "@/lib/hooks";
import { toast } from "sonner";
import { Sun } from "lucide-react";

export const Route = createFileRoute("/(landing)/register")({
  head: () => ({ meta: [{ title: "Register IPP — PMIS" }] }),
  component: RegisterPage,
});

function RegisterPage() {
  const navigate = useNavigate();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [org, setOrg] = useState("");
  const [password, setPassword] = useState("");
  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const u = db.registerUser({ name, email, org, password, role: "ipp" });
      session.set(u);
      toast.success("Registration complete. Welcome!");
      navigate({ to: "/ipp" });
    } catch (err) { toast.error((err as Error).message); }
  };
  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-b from-background via-muted/40 to-primary/[0.04] p-6">
      <div className="w-full max-w-md rounded-xl border border-primary/10 bg-card p-8 shadow-elegant">
        <Link to="/" className="mb-6 flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-primary to-primary/85 text-primary-foreground shadow-md shadow-primary/20 ring-1 ring-primary/20"><Sun className="h-5 w-5" /></div>
          <span className="font-semibold">PMIS</span>
        </Link>
        <h1 className="text-2xl font-semibold">Register as IPP</h1>
        <p className="text-sm text-muted-foreground mt-1">Create your Independent Power Producer account.</p>
        <form onSubmit={submit} className="mt-6 space-y-3">
          {[
            { label: "Full name", value: name, set: setName, type: "text" },
            { label: "Organization", value: org, set: setOrg, type: "text" },
            { label: "Email", value: email, set: setEmail, type: "email" },
            { label: "Password", value: password, set: setPassword, type: "password" },
          ].map((f) => (
            <div key={f.label}>
              <label className="text-sm font-medium">{f.label}</label>
              <input required type={f.type} value={f.value} onChange={(e) => f.set(e.target.value)}
                className="mt-1 w-full px-3 py-2 rounded-md border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
            </div>
          ))}
          <button type="submit" className="w-full rounded-md bg-gradient-to-b from-primary to-primary/92 py-2.5 text-sm font-semibold text-primary-foreground shadow-md shadow-primary/20 ring-1 ring-primary/15 transition hover:brightness-110">Create account</button>
        </form>
        <div className="mt-4 text-sm text-muted-foreground">Already registered? <Link to="/login" className="text-primary font-medium">Sign in</Link></div>
      </div>
    </div>
  );
}
