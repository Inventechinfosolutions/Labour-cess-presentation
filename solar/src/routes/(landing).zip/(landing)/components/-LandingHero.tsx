import { Link } from "@tanstack/react-router";
import { motion, useReducedMotion, useScroll, useSpring, useTransform } from "framer-motion";
import { Pause, Play, Sun } from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import { HeroBottomScrim, HeroGradientOverlay, HeroParallaxVideo, HeroStaticVideo } from "./-HeroBackdrop";

const springScroll = { stiffness: 40, damping: 30, mass: 0.5 } as const;

const CTA_CAPTION =
  "Schemes, applications, and milestone tracking — one transparent government workflow for solar and wind.";

export function LandingHero() {
  const sectionRef = useRef<HTMLElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const reduceMotion = useReducedMotion();
  const off = reduceMotion === true;
  const [videoPaused, setVideoPaused] = useState(false);

  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ["start start", "end start"],
  });

  const bgYRaw = useTransform(scrollYProgress, [0, 1], [0, off ? 0 : 220]);
  const bgScaleRaw = useTransform(scrollYProgress, [0, 1], [1, off ? 1 : 1.08]);
  const bgY = useSpring(bgYRaw, springScroll);
  const bgScale = useSpring(bgScaleRaw, springScroll);
  const copyYRaw = useTransform(scrollYProgress, [0, 0.32], [0, off ? 0 : 56]);
  const copyY = useSpring(copyYRaw, springScroll);

  useEffect(() => {
    const el = videoRef.current;
    if (!el) return;
    const sync = () => setVideoPaused(el.paused);
    sync();
    el.addEventListener("play", sync);
    el.addEventListener("pause", sync);
    return () => {
      el.removeEventListener("play", sync);
      el.removeEventListener("pause", sync);
    };
  }, [off]);

  const toggleVideo = useCallback(() => {
    const el = videoRef.current;
    if (!el) return;
    if (el.paused) void el.play();
    else el.pause();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative left-1/2 min-h-[100svh] w-screen max-w-[100vw] -translate-x-1/2 overflow-hidden bg-black text-white shadow-[inset_0_-1px_0_0_oklch(1_0_0/0.08)]"
      aria-label="Hero"
    >
      <div className="absolute inset-0 bg-black" aria-hidden />

      {off ? (
        <HeroStaticVideo ref={videoRef} className="absolute inset-[-12%] scale-[1.06]" />
      ) : (
        <HeroParallaxVideo ref={videoRef} parallaxY={bgY} parallaxScale={bgScale} />
      )}

      <HeroGradientOverlay variant="marketing" />

      <div
        className="pointer-events-none absolute inset-x-0 bottom-0 z-[1] h-[min(58vh,520px)] bg-gradient-to-t from-black/92 via-black/60 to-transparent"
        aria-hidden
      />
      <HeroBottomScrim variant="marketing" />

      {!off ? (
        <div className="absolute right-5 top-[calc(4.5rem+env(safe-area-inset-top))] z-[3] md:right-10 md:top-[calc(5rem+env(safe-area-inset-top))]">
          <button
            type="button"
            onClick={toggleVideo}
            className="flex size-10 items-center justify-center rounded-full border border-white/20 bg-black/35 text-white backdrop-blur-md transition-colors hover:bg-black/50 md:size-11"
            aria-pressed={!videoPaused}
            aria-label={videoPaused ? "Play background video" : "Pause background video"}
          >
            {videoPaused ? <Play className="size-4 pl-0.5" aria-hidden /> : <Pause className="size-4 fill-current" aria-hidden />}
          </button>
        </div>
      ) : null}

      <div className="relative z-[2] box-border flex min-h-[100svh] w-full max-w-[100vw] flex-col justify-end px-5 pb-10 pt-32 md:px-12 md:pb-14 lg:px-16 lg:pb-16">
        <motion.div
          className="mx-auto flex w-full max-w-[1800px] flex-col gap-10 md:flex-row md:items-end md:justify-between md:gap-16"
          style={off ? undefined : { y: copyY }}
        >
          <div className="max-w-[20rem] md:max-w-3xl lg:max-w-4xl">
            <div className="text-[13px] font-semibold uppercase tracking-[0.14em] text-white/70 md:text-sm">
              <span className="mr-2 inline-flex h-5 w-5 items-center justify-center rounded-sm bg-white/10 align-middle ring-1 ring-white/20">
                <Sun className="h-3 w-3" aria-hidden />
              </span>
              PMIS
            </div>
            <h1 className="mt-2 text-balance text-[2.35rem] font-semibold leading-[1.06] tracking-[-0.035em] text-white [text-shadow:0_2px_28px_rgba(0,0,0,0.92),0_1px_2px_rgba(0,0,0,0.6)] md:text-6xl lg:text-[4.5rem] lg:leading-[1.02]">
              One portal. Solar, wind, and every approval.
            </h1>
          </div>

          <div className="flex flex-col items-stretch gap-4 md:items-end">
            <div className="pointer-events-auto inline-flex w-full max-w-[44rem] flex-col overflow-hidden rounded-[2rem] border border-white/15 bg-black/45 p-1.5 shadow-[0_12px_48px_rgba(0,0,0,0.5)] backdrop-blur-2xl sm:flex-row sm:items-center sm:rounded-full sm:pl-5 sm:pr-1.5 md:w-auto md:max-w-[40rem]">
              <p className="m-0 flex min-w-0 flex-col gap-0.5 px-4 pb-2 pt-3 text-[14px] leading-snug text-white/90 sm:h-10 sm:min-w-[18rem] sm:max-w-[28rem] sm:shrink sm:flex-row sm:items-center sm:gap-3 sm:py-0 sm:pl-0 sm:pr-5 sm:text-[15px] sm:leading-none">
                {CTA_CAPTION}
              </p>
              <div className="flex shrink-0 pt-0 sm:items-stretch sm:p-0">
                <Link
                  to="/register"
                  className="inline-flex h-11 w-full items-center justify-center rounded-full bg-[#0071e3] px-8 text-[15px] font-medium text-white transition hover:bg-[#0077ed] active:bg-[#0066cc] sm:h-10 sm:w-auto sm:min-w-[7.25rem]"
                >
                  Register
                </Link>
              </div>
            </div>
            <a
              href="#opportunities"
              className="self-start text-[15px] font-medium text-white/75 transition-colors hover:text-white md:self-end"
            >
              Browse opportunities
            </a>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
