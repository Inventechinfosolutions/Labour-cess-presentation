import { Link } from "@tanstack/react-router";
import { ArrowUpRight, ChevronRight, Shield } from "lucide-react";
import { ScrollReveal } from "./-ScrollReveal";

const FOOTER_LINKS = [
  { href: "#", label: "Privacy" },
  { href: "#", label: "Terms" },
  { href: "#", label: "Help" },
] as const;

export function LandingFooter() {
  return (
    <footer className="relative overflow-hidden border-t border-primary/10 bg-gradient-to-b from-muted/40 via-background to-muted/25 py-14 md:py-20">
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.35] dark:opacity-[0.2]"
        style={{
          backgroundImage: `radial-gradient(oklch(0.45 0.08 252 / 0.07) 1px, transparent 1px)`,
          backgroundSize: "22px 22px",
        }}
        aria-hidden
      />
      <div
        className="pointer-events-none absolute left-0 right-0 top-0 h-[3px] bg-gradient-to-r from-transparent via-amber-400/85 via-40% to-teal-600/80 to-transparent opacity-95"
        aria-hidden
      />
      <div className="pointer-events-none absolute -right-24 top-1/4 size-[420px] rounded-full bg-gradient-to-br from-renewable-wind/12 to-transparent blur-3xl dark:from-renewable-wind/8" aria-hidden />
      <div className="pointer-events-none absolute -left-32 bottom-0 size-[380px] rounded-full bg-gradient-to-tr from-renewable-solar/10 to-transparent blur-3xl dark:from-renewable-solar/6" aria-hidden />

      <div className="relative z-[1] mx-auto w-full max-w-[100vw] px-4 sm:px-6 md:px-8 lg:px-12 xl:px-16 2xl:px-20">
        <ScrollReveal>
          <div className="overflow-hidden rounded-3xl border border-primary/12 bg-gradient-to-br from-card/95 via-card/85 to-teal-50/30 shadow-[0_28px_80px_-40px_oklch(0.28_0.08_262/0.35)] ring-1 ring-primary/8 backdrop-blur-xl dark:from-card/80 dark:via-card/70 dark:to-primary/[0.07] dark:ring-primary/15">
            <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/70 to-transparent dark:via-white/10" aria-hidden />
            <div className="relative grid gap-10 p-8 md:grid-cols-12 md:gap-12 md:p-10 lg:p-12">
              <div className="md:col-span-5">
                <span className="inline-flex items-center gap-2 rounded-full border border-teal-600/35 bg-teal-50/90 px-3 py-1 text-[0.65rem] font-bold uppercase tracking-[0.14em] text-teal-950 shadow-sm dark:border-teal-400/25 dark:bg-teal-950/40 dark:text-teal-100">
                  <Shield className="size-3.5" aria-hidden />
                  Renewable energy portal
                </span>
                <p className="mt-5 text-pretty text-base font-medium leading-relaxed text-foreground/90 md:text-[1.05rem]">
                  PMIS — transparent digital workflow for solar and wind project approvals, SLA tracking, and milestone
                  governance.
                </p>
                <p className="mt-4 max-w-sm text-sm leading-relaxed text-muted-foreground">
                  Built for public-sector rigor: every transition is traceable, and dashboards keep leadership aligned
                  with ground truth.
                </p>
              </div>

              <div className="flex flex-col justify-between gap-8 md:col-span-4">
                <div>
                  <h3 className="text-xs font-bold uppercase tracking-[0.18em] text-muted-foreground">Resources</h3>
                  <ul className="mt-4 space-y-1">
                    {FOOTER_LINKS.map((item) => (
                      <li key={item.label}>
                        <a
                          href={item.href}
                          className="group flex items-center justify-between gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold text-foreground/80 transition hover:bg-primary/[0.06] hover:text-primary"
                        >
                          <span className="flex items-center gap-2">
                            <ChevronRight
                              className="size-4 text-primary/40 transition group-hover:translate-x-0.5 group-hover:text-primary"
                              aria-hidden
                            />
                            {item.label}
                          </span>
                          <ArrowUpRight className="size-4 shrink-0 opacity-0 transition group-hover:opacity-100" aria-hidden />
                        </a>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="flex flex-col justify-end md:col-span-3">
                <div className="rounded-2xl border border-primary/10 bg-gradient-to-br from-primary/[0.07] to-renewable-wind/[0.06] p-5 ring-1 ring-inset ring-white/60 dark:ring-white/5">
                  <h3 className="text-xs font-bold uppercase tracking-[0.18em] text-muted-foreground">Staff access</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                    Officers, approvers, and admins sign in with institutional credentials.
                  </p>
                  <Link
                    to="/login"
                    className="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-primary px-4 py-3 text-sm font-semibold text-primary-foreground shadow-lg shadow-primary/25 transition hover:brightness-110 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                  >
                    Staff login
                    <ArrowUpRight className="size-4" aria-hidden />
                  </Link>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-10 flex flex-col gap-4 border-t border-primary/10 pt-8 text-sm md:flex-row md:items-center md:justify-between">
            <p className="font-medium text-muted-foreground">© 2026 PMIS · Renewable Project Management System</p>
            <Link
              to="/"
              className="text-sm font-semibold text-primary underline-offset-4 transition hover:underline md:order-first"
            >
              Back to home
            </Link>
          </div>
        </ScrollReveal>
      </div>
    </footer>
  );
}
