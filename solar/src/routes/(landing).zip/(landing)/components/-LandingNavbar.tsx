import { Link } from "@tanstack/react-router";
import { Menu, Search, Sun, UserRound, X } from "lucide-react";
import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";

const NAV = [
  { href: "#about", label: "About" },
  { href: "#opportunities", label: "Opportunities" },
  { href: "#how", label: "How it works" },
  { href: "#announcements", label: "Notices" },
] as const;

const linkClass =
  "whitespace-nowrap text-[0.7rem] font-normal tracking-[-0.01em] text-zinc-100/78 transition-[opacity,color] duration-200 hover:text-white hover:opacity-100 sm:text-xs";

export function LandingNavbar() {
  const [open, setOpen] = useState(false);

  return (
    <header
      className="fixed top-0 left-0 right-0 z-50 h-11 border-b border-white/[0.12] bg-zinc-950/55 text-zinc-100 shadow-[0_1px_0_0_rgba(255,255,255,0.06),inset_0_1px_0_0_rgba(255,255,255,0.04)] backdrop-blur-2xl backdrop-saturate-150 [transform:translateZ(0)] dark:bg-zinc-950/65"
      style={{ WebkitBackdropFilter: "saturate(1.1) blur(20px)" }}
    >
      <div className="mx-auto flex h-full w-full max-w-5xl items-stretch px-3 sm:px-5 md:px-6 lg:max-w-6xl">
        <div className="flex min-w-0 flex-1 items-center justify-start">
          <Link
            to="/"
            className="group flex min-w-0 items-center gap-1.5 opacity-90 transition-opacity hover:opacity-100"
            onClick={() => setOpen(false)}
            aria-label="PMIS home"
          >
            <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-md bg-gradient-to-b from-amber-400/95 to-amber-500/80 text-amber-950 shadow-sm shadow-amber-950/25 ring-1 ring-white/20">
              <Sun className="h-3.5 w-3.5" aria-hidden />
            </span>
            <span className="hidden truncate text-xs font-medium tracking-[-0.02em] text-zinc-100/95 sm:inline sm:text-[0.8rem]">
              PMIS
            </span>
          </Link>
        </div>

        <nav
          className="hidden items-center justify-center gap-6 text-center md:static md:flex md:gap-7 md:px-1 lg:gap-9"
          aria-label="Primary"
        >
          {NAV.map((item) => (
            <a key={item.href} href={item.href} className={linkClass}>
              {item.label}
            </a>
          ))}
        </nav>

        <div className="flex min-w-0 flex-1 items-center justify-end gap-1.5 pr-0.5 sm:gap-3 sm:pr-0">
          <a
            href="#opportunities"
            className="hidden p-1.5 text-zinc-200/80 transition-[opacity,transform] hover:text-white sm:inline-flex"
            aria-label="Search opportunities"
          >
            <Search className="h-4 w-4" strokeWidth={1.5} />
          </a>
          <Link
            to="/login"
            className="hidden p-1.5 text-zinc-200/80 transition hover:text-white sm:inline-flex"
            aria-label="Sign in"
          >
            <UserRound className="h-4 w-4" strokeWidth={1.5} />
          </Link>
          <Link
            to="/register"
            className="hidden text-[0.7rem] font-medium text-amber-100/90 transition hover:text-white sm:inline-flex"
          >
            Register
          </Link>
          <button
            type="button"
            className="inline-flex h-8 w-8 items-center justify-center rounded-md text-zinc-200/90 transition hover:bg-white/10 hover:text-white md:hidden"
            aria-expanded={open}
            aria-controls="mobile-nav-apple"
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X className="h-4 w-4" strokeWidth={1.5} /> : <Menu className="h-4 w-4" strokeWidth={1.5} />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {open ? (
          <motion.div
            id="mobile-nav-apple"
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
            className="overflow-hidden border-t border-white/10 bg-zinc-950/60 backdrop-blur-2xl md:hidden"
          >
            <nav className="flex flex-col px-4 py-2 pb-4" aria-label="Mobile">
              {NAV.map((item) => (
                <a
                  key={item.href}
                  href={item.href}
                  className="border-b border-white/5 py-2.5 text-sm font-normal text-zinc-200/90 transition first:pt-1 last:border-b-0 hover:text-white"
                  onClick={() => setOpen(false)}
                >
                  {item.label}
                </a>
              ))}
              <div className="mt-2 flex items-center justify-between border-t border-white/10 pt-3">
                <a href="#opportunities" className="flex items-center gap-2 text-sm text-zinc-300" onClick={() => setOpen(false)}>
                  <Search className="h-4 w-4" />
                  Find schemes
                </a>
                <div className="flex gap-3 text-sm">
                  <Link to="/login" className="text-zinc-300" onClick={() => setOpen(false)}>
                    Sign in
                  </Link>
                  <Link to="/register" className="font-medium text-amber-200" onClick={() => setOpen(false)}>
                    Register
                  </Link>
                </div>
              </div>
            </nav>
          </motion.div>
        ) : null}
      </AnimatePresence>
    </header>
  );
}
