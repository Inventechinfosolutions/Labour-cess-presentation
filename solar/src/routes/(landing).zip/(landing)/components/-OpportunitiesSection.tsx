import { Link } from "@tanstack/react-router";
import { motion, useReducedMotion } from "framer-motion";
import { ArrowRight, Briefcase, MapPin, Route, Search, Zap } from "lucide-react";
import { Fragment, useRef } from "react";
import type { Opportunity } from "@/lib/types";
import { cn } from "@/lib/utils";
import { RenewableAmbientLayer } from "./-HeroBackdrop";
import { ScrollReveal, ScrollRevealItem, ScrollRevealStagger } from "./-ScrollReveal";
import { useBandParallaxMotion } from "./-useBandParallax";

const ROUTE_WAYPOINTS = [
  { label: "Published", icon: Search },
  { label: "Compare", icon: Route },
  { label: "Login", icon: Briefcase },
  { label: "Apply", icon: Zap },
] as const;

function typeStripe(type: Opportunity["type"]) {
  if (type === "Solar") return "from-renewable-solar via-amber-400/90 to-renewable-solar";
  if (type === "Wind") return "from-renewable-wind via-primary/80 to-renewable-wind";
  return "from-renewable-solar via-primary to-renewable-wind";
}

function ApplicationRouteStrip() {
  return (
    <div
      className="relative rounded-2xl border border-primary/10 bg-white/40 p-4 shadow-inner shadow-primary/[0.04] backdrop-blur-md dark:border-primary/15 dark:bg-card/40 md:p-5"
      aria-label="Typical application route"
    >
      <p className="text-center text-[0.65rem] font-bold uppercase tracking-[0.18em] text-muted-foreground">
        Your route to an application
      </p>
      <ol className="mt-4 flex flex-col items-center gap-0 md:flex-row md:flex-wrap md:items-center md:justify-center">
        {ROUTE_WAYPOINTS.map((wp, i) => {
          const Icon = wp.icon;
          const isLast = i === ROUTE_WAYPOINTS.length - 1;
          return (
            <Fragment key={wp.label}>
              <li className="flex w-full max-w-sm items-center gap-3 md:w-auto md:max-w-none md:flex-col md:gap-2 md:px-3">
                <div className="flex size-10 shrink-0 items-center justify-center rounded-full border-2 border-primary/20 bg-gradient-to-br from-white to-teal-50/90 text-primary shadow-sm ring-1 ring-primary/10 dark:border-primary/25 dark:from-card dark:to-primary/10">
                  <Icon className="size-4" aria-hidden />
                </div>
                <span className="text-sm font-semibold text-foreground md:text-center md:text-xs">{wp.label}</span>
              </li>
              {!isLast ? (
                <li
                  className="flex h-7 w-full max-w-sm items-center justify-center py-1 md:h-auto md:w-12 md:max-w-none md:shrink-0 md:py-0"
                  aria-hidden
                >
                  <div className="h-full w-0.5 rounded-full bg-gradient-to-b from-primary/55 via-primary/35 to-primary/15 md:h-0.5 md:w-full md:bg-gradient-to-r" />
                </li>
              ) : null}
            </Fragment>
          );
        })}
      </ol>
    </div>
  );
}

export function OpportunitiesSection({ opportunities }: { opportunities: Opportunity[] }) {
  const sectionRef = useRef<HTMLElement | null>(null);
  const px = useBandParallaxMotion(sectionRef);
  const reduce = useReducedMotion();

  return (
    <section
      ref={sectionRef}
      id="opportunities"
      className="relative isolate overflow-hidden border-y border-primary/10 py-20 md:py-28"
      aria-labelledby="opps-heading"
    >
      <div className="pointer-events-none absolute inset-0 z-0 overflow-hidden" aria-hidden>
        <motion.div
          className="absolute inset-0"
          style={px.off ? undefined : { y: px.imgY, scale: px.imgScale }}
        >
          <RenewableAmbientLayer className="opacity-[0.13] max-md:opacity-[0.1] bg-[center_45%]" />
        </motion.div>
        <motion.div className="absolute inset-0" style={px.off ? undefined : { y: px.washY }}>
          <div className="absolute inset-0 bg-gradient-to-b from-teal-50/70 via-primary/[0.07] to-amber-50/40 dark:from-background/92 dark:via-primary/[0.12] dark:to-background/90" />
          <div className="absolute inset-0 bg-[linear-gradient(oklch(0.5_0.06_200/0.035)_1px,transparent_1px),linear-gradient(90deg,oklch(0.5_0.06_200/0.035)_1px,transparent_1px)] bg-[size:40px_40px] opacity-40 dark:opacity-25" />
        </motion.div>
      </div>
      <motion.div
        className="pointer-events-none absolute inset-0 z-[1] bg-[radial-gradient(ellipse_80%_50%_at_10%_20%,oklch(0.68_0.11_200/0.28),transparent_55%),radial-gradient(ellipse_70%_45%_at_92%_30%,oklch(0.78_0.14_72/0.22),transparent_52%),radial-gradient(ellipse_55%_35%_at_50%_90%,oklch(0.45_0.1_252/0.1),transparent_50%)] dark:bg-[radial-gradient(ellipse_80%_50%_at_10%_20%,oklch(0.48_0.1_200/0.2),transparent_55%),radial-gradient(ellipse_70%_45%_at_92%_30%,oklch(0.5_0.1_72/0.14),transparent_52%)]"
        style={px.off ? undefined : { y: px.orbsY }}
        aria-hidden
      />
      <div
        className="pointer-events-none absolute right-0 top-1/4 size-96 translate-x-1/4 rounded-full bg-gradient-to-bl from-renewable-wind/12 to-transparent blur-3xl"
        aria-hidden
      />

      <div className="relative z-10 mx-auto w-full max-w-6xl px-4 sm:px-6 md:px-8 lg:px-10">
        <ScrollReveal>
          <div className="flex flex-col gap-8 lg:flex-row lg:items-end lg:justify-between">
            <div className="max-w-2xl">
              <motion.div style={px.off ? undefined : { y: px.leadY }}>
                <span className="inline-flex items-center gap-2 rounded-full border border-teal-600/40 bg-teal-50/90 px-3.5 py-1.5 text-[0.65rem] font-bold uppercase tracking-[0.14em] text-teal-950 shadow-sm backdrop-blur-md dark:border-teal-500/30 dark:bg-primary/20 dark:text-teal-50">
                  <Route className="size-3.5" aria-hidden />
                  Open opportunities
                </span>
                <h2
                  id="opps-heading"
                  className="mt-4 text-balance text-3xl font-semibold leading-[1.12] tracking-tight text-foreground md:text-4xl"
                >
                  <span className="bg-gradient-to-r from-foreground via-primary to-renewable-wind bg-clip-text text-transparent">
                    Active schemes
                  </span>{" "}
                  on the national map
                </h2>
                <p className="mt-4 max-w-xl text-sm leading-relaxed text-muted-foreground md:text-base">
                  Each listing is a waypoint — pick a cluster, attach documents, and track reviewer milestones in one
                  workspace.
                </p>
              </motion.div>
            </div>
            <motion.div className="shrink-0" style={px.off ? undefined : { y: px.trailY }}>
              <Link
                to="/login"
                className="group inline-flex items-center justify-center gap-2 rounded-xl bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground shadow-lg shadow-primary/25 ring-1 ring-primary/20 transition hover:brightness-110 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
              >
                <Zap className="size-4 text-primary-foreground/90" aria-hidden />
                Login to apply
                <ArrowRight className="size-4 transition-transform group-hover:translate-x-0.5" aria-hidden />
              </Link>
            </motion.div>
          </div>
        </ScrollReveal>

        <motion.div className="mt-6" style={px.off ? undefined : { y: px.leadY }}>
          <ApplicationRouteStrip />
        </motion.div>

        <motion.div className="relative mt-12" style={px.off ? undefined : { y: px.trailY }}>
          <div
            className="pointer-events-none absolute left-[8%] right-[8%] top-1/2 hidden h-0.5 -translate-y-1/2 rounded-full bg-gradient-to-r from-renewable-solar/25 via-primary/15 to-renewable-wind/25 lg:block"
            aria-hidden
          />
          <ScrollRevealStagger className="relative z-[1] grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {opportunities.map((o, idx) => (
              <ScrollRevealItem key={o.id}>
                <motion.article
                  whileHover={reduce ? undefined : { y: -5 }}
                  transition={{ type: "spring", stiffness: 400, damping: 24 }}
                  className="group relative flex h-full flex-col overflow-hidden rounded-2xl border border-primary/12 bg-gradient-to-b from-white/90 via-white/75 to-teal-50/30 p-5 shadow-[0_22px_55px_-36px_oklch(0.28_0.08_262/0.3)] ring-1 ring-white/80 backdrop-blur-xl transition duration-300 hover:border-primary/22 hover:shadow-xl dark:from-card/85 dark:via-card/70 dark:to-primary/[0.08] dark:ring-primary/10"
                >
                  <div
                    className={cn(
                      "pointer-events-none absolute inset-x-0 top-0 h-1 bg-gradient-to-r opacity-95",
                      typeStripe(o.type),
                    )}
                    aria-hidden
                  />
                  <div
                    className="pointer-events-none absolute inset-x-[-35%] bottom-[-55%] h-40 bg-[radial-gradient(closest-side,oklch(0.62_0.12_200/0.2),transparent_72%)] opacity-50 transition duration-500 group-hover:opacity-100"
                    aria-hidden
                  />
                  <div className="relative z-[1] flex items-start justify-between gap-2">
                    <span className="inline-flex items-center gap-1.5 rounded-full border border-primary/15 bg-primary/[0.06] px-2 py-0.5 text-[0.6rem] font-bold uppercase tracking-wider text-primary">
                      <MapPin className="size-3 opacity-80" aria-hidden />
                      Waypoint {idx + 1}
                    </span>
                    <span className="shrink-0 rounded-full bg-success/15 px-2.5 py-0.5 text-[11px] font-bold text-success ring-1 ring-success/20">
                      {o.status}
                    </span>
                  </div>
                  <div className="relative z-[1] mt-2 space-y-0.5">
                    <span className="block font-mono text-[11px] font-bold uppercase tracking-wider text-primary/80">
                      {o.code}
                    </span>
                    {o.referenceCode ? (
                      <span className="block font-mono text-[10px] font-semibold tracking-wide text-foreground/90">
                        {o.referenceCode}
                      </span>
                    ) : null}
                  </div>
                  <h3 className="relative z-[1] mt-2 text-lg font-semibold leading-snug tracking-tight text-foreground">
                    {o.name}
                  </h3>
                  <p className="relative z-[1] mt-2 flex items-center gap-1.5 text-xs text-muted-foreground">
                    <MapPin className="size-3.5 shrink-0 text-renewable-wind" aria-hidden />
                    {o.state} · {o.district}
                  </p>
                  <div className="relative z-[1] mt-5 flex flex-wrap items-end justify-between gap-3 border-t border-primary/10 pt-4">
                    <div>
                      <div className="text-[0.65rem] font-bold uppercase tracking-wider text-muted-foreground">
                        Capacity
                      </div>
                      <div className="mt-0.5 text-2xl font-bold tabular-nums tracking-tight text-foreground">
                        {o.capacityMW}
                        <span className="ml-1 text-sm font-semibold text-muted-foreground">MW</span>
                      </div>
                    </div>
                    <span
                      className={cn(
                        "rounded-lg px-2.5 py-1 text-xs font-bold",
                        o.type === "Solar" && "bg-amber-100/90 text-amber-950 dark:bg-amber-950/40 dark:text-amber-100",
                        o.type === "Wind" && "bg-teal-100/90 text-teal-950 dark:bg-teal-950/40 dark:text-teal-100",
                        o.type === "Hybrid" &&
                          "bg-primary/12 text-primary dark:bg-primary/25 dark:text-primary-foreground",
                      )}
                    >
                      {o.type}
                    </span>
                  </div>
                  <p className="relative z-[1] mt-3 line-clamp-2 text-xs leading-relaxed text-muted-foreground">
                    {o.description}
                  </p>
                  <Link
                    to="/login"
                    className="relative z-[1] mt-5 inline-flex items-center gap-1.5 text-sm font-semibold text-primary transition hover:gap-2.5"
                  >
                    View details
                    <ArrowRight className="size-4" aria-hidden />
                  </Link>
                </motion.article>
              </ScrollRevealItem>
            ))}
          </ScrollRevealStagger>
        </motion.div>
      </div>

      <div
        className="pointer-events-none absolute bottom-0 left-0 right-0 z-[2] h-px bg-gradient-to-r from-transparent via-teal-500/50 to-transparent"
        aria-hidden
      />
    </section>
  );
}
